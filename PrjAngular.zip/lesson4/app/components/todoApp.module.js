(function(angular){
    'use strict'
    var module = angular.module('todoApp', ['ngMaterial','ngAnimate']);


})(window.angular);